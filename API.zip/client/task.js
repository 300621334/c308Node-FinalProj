"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = /** @class */ (function () {
    function Course() {
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=task.js.map