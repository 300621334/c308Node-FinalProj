export class Course{
    _id : number;
    title: string;
    author:string;
    section:string;
    isbn:string;
}