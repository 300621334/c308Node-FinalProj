module.exports={
    "URI" : "mongodb://localhost:27017/MEAN_app-db"
}